'use strict'
// minimatch 3.x-compatible API over the patched 11.0.3 implementation.
// Provenance: API contract from minimatch@3.1.5 (ISC, isaacs); implementation
// delegated to minimatch@11.0.3 (ISC, isaacs) via the aliased dependency
// "minimatch-11". No code copied from either; this file is a thin adapter.
const mm11 = require('minimatch-11')

// 3.x `windowsPathsNoEscape: true` means "backslashes are literal, do not treat
// as path separators". 11 renamed and inverted this to `allowWindowsEscape`.
// 3.x DEFAULT behavior (windowsPathsNoEscape: false) converts backslashes to
// separators, which is 11's `allowWindowsEscape: true` (its default in some
// versions but pinned here explicitly so behavior never depends on defaults).
function mapOptions(options) {
  // minimatch 11 honors the legacy windowsPathsNoEscape option natively, and
  // 11-native consumers (e.g. glob's Ignore/processor) pass it explicitly.
  // When the caller states either windows-escape option, pass everything
  // through untouched. Only when the caller states NEITHER (the 3.x-consumer
  // default) do we inject allowWindowsEscape: true, which restores 3.x
  // matching semantics on win32 and is behavior-neutral on POSIX.
  if (!options) return { allowWindowsEscape: true }
  if (options.allowWindowsEscape !== undefined || options.windowsPathsNoEscape !== undefined) {
    return options
  }
  return Object.assign({ allowWindowsEscape: true }, options)
}

function minimatch3(target, pattern, options) {
  return mm11.minimatch(target, pattern, mapOptions(options))
}

class Minimatch3 extends mm11.Minimatch {
  constructor(pattern, options) {
    super(pattern, mapOptions(options))
  }
}

minimatch3.Minimatch = Minimatch3
minimatch3.minimatch = minimatch3
minimatch3.match = (list, pattern, options) => mm11.match(list, pattern, mapOptions(options))
minimatch3.filter = (pattern, options) => mm11.filter(pattern, mapOptions(options))
minimatch3.defaults = (options) => {
  // 3.x defaults() returns a wrapped module; wrap recursively via bound options.
  const bound = mapOptions(options)
  const wrapped = (target, pattern, o) => mm11.minimatch(target, pattern, Object.assign({}, bound, mapOptions(o)))
  wrapped.Minimatch = class extends mm11.Minimatch { constructor(p, o) { super(p, Object.assign({}, bound, mapOptions(o))) } }
  wrapped.match = (list, pattern, o) => mm11.match(list, pattern, Object.assign({}, bound, mapOptions(o)))
  wrapped.filter = (pattern, o) => mm11.filter(pattern, Object.assign({}, bound, mapOptions(o)))
  return wrapped
}
minimatch3.braceExpand = (pattern, options) => mm11.braceExpand(pattern, mapOptions(options))
minimatch3.GLOBSTAR = mm11.GLOBSTAR
minimatch3.escape = (str, options) => mm11.escape(str, options)
minimatch3.unescape = (str, options) => mm11.unescape(str, options)
// 3.x makeRe(pattern, options) -> RegExp|false. The 10/11 architecture matches
// on parsed globParts sets and compiles NO RegExp, so there is no upstream
// regex to hand back. This returns a genuine RegExp subclass whose test()
// delegates to the patched 11 matcher, giving exact 3.x test() semantics
// (3.x match() itself is `makeRe().test(file)`). .source/.flags are cosmetic;
// the one installed consumer (eslint-plugin-import no-internal-modules, not
// enabled in the repo config) calls only .test(). comment/empty patterns
// return false, exactly as 3.x.
minimatch3.makeRe = (pattern, options) => {
  const mm = new Minimatch3(pattern, mapOptions(options))
  if (mm.comment || mm.empty) return false
  const unsupported = (what) => () => {
    throw new Error(
      'minimatch 3.x-compat makeRe: the 10/11 architecture compiles no RegExp, so only ' +
      'test() is supported (delegated to the patched 11 matcher). ' + what +
      ' is a loud failure by design rather than a silently wrong result.')
  }
  class MatchRegExp extends RegExp {
    test(str) { return mm.match(str) }
    exec() { throw unsupported('exec()')() }
    [Symbol.match]() { throw unsupported('Symbol.match')() }
    [Symbol.matchAll]() { throw unsupported('Symbol.matchAll')() }
    [Symbol.replace]() { throw unsupported('Symbol.replace')() }
    [Symbol.search]() { throw unsupported('Symbol.search')() }
    [Symbol.split]() { throw unsupported('Symbol.split')() }
  }
  return new MatchRegExp('', mm.options.nocase ? 'i' : '')
}
// Not carried over (unused by any installed consumer, absent in 11):
// Minimatch.prototype.matchOne. Its absence is deliberate and loud
// (undefined), not a silent stub.
module.exports = minimatch3
