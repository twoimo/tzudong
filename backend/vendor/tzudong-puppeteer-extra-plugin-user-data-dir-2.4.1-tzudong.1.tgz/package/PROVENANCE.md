Vendored from puppeteer-extra-plugin-user-data-dir@2.4.1
- Upstream: https://github.com/berstend/puppeteer-extra (gitHead 2f4a357f233b35a7a20f16ce007f5ef3f62765b9), MIT license (LICENSE included verbatim).
- Reason: upstream is archived; 2.4.1 depends on rimraf@^3.0.2, which pulls glob@7 / minimatch@3 flagged by GHSA-3g3m-2fjr-6pw4 / GHSA-g3hv-75wg-m249.
- Sole change: deleteUserDataDir() uses Node-native fs.rm({recursive, force, maxRetries: 4, retryDelay: 100}) instead of rimraf(path, {maxBusyTries: 4}, cb). Same async-callback shape, same ENOENT-is-success behavior, same busy-retry schedule; fs.rm never glob-expands (deletion is literal).
- engines raised from >=8 to >=14.14 (fs.rm availability). Backend runs Node 24 in CI.
- No install lifecycle scripts. devDependencies and dev-only scripts from upstream are omitted.
